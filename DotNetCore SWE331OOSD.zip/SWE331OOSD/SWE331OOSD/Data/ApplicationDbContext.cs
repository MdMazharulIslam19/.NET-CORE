﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using SWE331OOSD.Models;

namespace SWE331OOSD.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<SWE331OOSD.Models.Semester> Semester { get; set; }
        public DbSet<SWE331OOSD.Models.Student> Student { get; set; }
    }
}
