﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SWE331OOSD.Models
{
    public class Semester
    {
        public int SemesterId { get; set; }
        [Required]
        [Display(Name = "Semester Name")]
        public string SemesterName { get; set; }

        public List<Student> student { get; set; }
    }
}
