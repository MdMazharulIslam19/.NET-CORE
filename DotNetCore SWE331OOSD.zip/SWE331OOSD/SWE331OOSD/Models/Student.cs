﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SWE331OOSD.Models
{
    public class Student
    {
        public int StudentId { get; set; }
        [Required]
        [Display(Name = "Student Name")]
        public string StudentName { get; set; }
        public int SemesterId { get; set; }
        
        public Semester semester { get; set;}
    }
}
